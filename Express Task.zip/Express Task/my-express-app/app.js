
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcrypt');
const csurf = require('csurf');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const mysql = require('mysql');

const app = express();


app.use(helmet());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use((req, res, next) => {
  if (req.body) {
    for (const key in req.body) {
      if (typeof req.body[key] === 'string') {
        req.body[key] = req.body[key].replace(/</g, "&lt;").replace(/>/g, "&gt;");
      }
    }
  }
  next();
});


const csrfProtection = csurf({ cookie: true });


const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Too many login attempts, try later'
});


const SECRET = 'supersecretkey';


app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');


const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'secure_web_app'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL!');
});


function createToken(username) {
  return jwt.sign({ username }, SECRET, { expiresIn: '1h' });
}


function authenticateToken(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.redirect('/login-page');

  jwt.verify(token, SECRET, (err, user) => {
    if (err) return res.redirect('/login-page');
    req.user = user;
    next();
  });
}


app.get('/', (req, res) => {
  const token = req.cookies.token;
  let username = null;
  if (token) {
    try {
      const user = jwt.verify(token, SECRET);
      username = user.username;
    } catch (e) {}
  }
  res.render('home', { username });
});

app.get('/register', (req, res) => {
  res.render('register', { errors: [] });
});

app.post('/register', [
  body('username').isAlphanumeric().withMessage('Username must be alphanumeric'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters long')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('register', { errors: errors.array() });
  }

  const { username, password } = req.body;
  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err) return res.status(500).send('Database error');
    if (results.length > 0) return res.render('register', { errors: [{ msg: 'User already exists' }] });

    const hashed = await bcrypt.hash(password, 10);
    db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashed], (err, result) => {
      if (err) return res.status(500).send('Database error');
      db.query('INSERT INTO assets (user_id, balance) VALUES (?, ?)', [result.insertId, 100], (err) => {
        if (err) return res.status(500).send('Database error');
        res.redirect('/login-page');
      });
    });
  });
});

app.get('/login-page', (req, res) => {
  res.render('login', { errors: [] });
});

app.post('/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body;
  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err) return res.status(500).send('Database error');
    if (results.length === 0) return res.render('login', { errors: [{ msg: 'Invalid credentials' }] });

    const valid = await bcrypt.compare(password, results[0].password);
    if (!valid) return res.render('login', { errors: [{ msg: 'Invalid credentials' }] });

    const token = createToken(username);
    res.cookie('token', token, { httpOnly: true });
    res.redirect('/dashboard');
  });
});

app.get('/dashboard', authenticateToken, (req, res) => {
  const username = req.user.username;
  db.query('SELECT assets.balance FROM users JOIN assets ON users.id = assets.user_id WHERE users.username = ?', [username], (err, results) => {
    if (err || results.length === 0) return res.status(500).send('Error retrieving balance');
    res.render('dashboard', { username, balance: results[0].balance });
  });
});

app.get('/balance', authenticateToken, (req, res) => {
  const username = req.user.username;
  db.query('SELECT assets.balance FROM users JOIN assets ON users.id = assets.user_id WHERE users.username = ?', [username], (err, results) => {
    if (err || results.length === 0) return res.status(500).send('Error retrieving balance');
    res.render('balance', { username, balance: results[0].balance });
  });
});

app.get('/transfer-page', authenticateToken, csrfProtection, (req, res) => {
  res.render('transfer', { csrfToken: req.csrfToken() });
});

// app.post('/transfer', authenticateToken, csrfProtection, (req, res) => {
//   const fromUsername = req.user.username;
//   const { to, amount } = req.body;

//   db.query('SELECT id FROM users WHERE username = ?', [fromUsername], (err, fromResults) => {
//     if (err || fromResults.length === 0) return res.status(500).send('Sender not found');
//     const fromUserId = fromResults[0].id;

//     db.query('SELECT id FROM users WHERE username = ?', [to], (err, toResults) => {
//       if (err || toResults.length === 0) return res.status(400).send('Recipient not found');
//       const toUserId = toResults[0].id;

//       db.query('SELECT balance FROM assets WHERE user_id = ?', [fromUserId], (err, balanceResults) => {
//         if (err || balanceResults.length === 0) return res.status(400).send('Sender balance not found');
//         const senderBalance = parseFloat(balanceResults[0].balance);

//         if (senderBalance < amount) return res.status(400).send('Insufficient balance');

//         db.beginTransaction(err => {
//           if (err) return res.status(500).send('Transaction error');

//           db.query('UPDATE assets SET balance = balance - ? WHERE user_id = ?', [amount, fromUserId], err => {
//             if (err) return db.rollback(() => res.status(500).send('Error debiting sender'));

//             db.query('UPDATE assets SET balance = balance + ? WHERE user_id = ?', [amount, toUserId], err => {
//               if (err) return db.rollback(() => res.status(500).send('Error crediting recipient'));

//               db.commit(err => {
//                 if (err) return db.rollback(() => res.status(500).send('Commit failed'));
//                 res.redirect('/dashboard');
//               });
//             });
//           });
//         });
//       });
//     });
//   });
// });


app.post('/transfer', authenticateToken, csrfProtection, (req, res) => {
  const fromUsername = req.user.username;
  const { to, amount } = req.body;

  const numericAmount = parseFloat(amount);

  // Check if amount is a valid positive number
  if (isNaN(numericAmount) || numericAmount <= 0) {
    return res.status(400).send('Transfer amount must be a positive number');
  }

  db.query('SELECT id FROM users WHERE username = ?', [fromUsername], (err, fromResults) => {
    if (err || fromResults.length === 0) return res.status(500).send('Sender not found');
    const fromUserId = fromResults[0].id;

    db.query('SELECT id FROM users WHERE username = ?', [to], (err, toResults) => {
      if (err || toResults.length === 0) return res.status(400).send('Recipient not found');
      const toUserId = toResults[0].id;

      db.query('SELECT balance FROM assets WHERE user_id = ?', [fromUserId], (err, balanceResults) => {
        if (err || balanceResults.length === 0) return res.status(400).send('Sender balance not found');
        const senderBalance = parseFloat(balanceResults[0].balance);

        if (senderBalance < numericAmount) return res.status(400).send('Insufficient balance');

        db.beginTransaction(err => {
          if (err) return res.status(500).send('Transaction error');

          db.query('UPDATE assets SET balance = balance - ? WHERE user_id = ?', [numericAmount, fromUserId], err => {
            if (err) return db.rollback(() => res.status(500).send('Error debiting sender'));

            db.query('UPDATE assets SET balance = balance + ? WHERE user_id = ?', [numericAmount, toUserId], err => {
              if (err) return db.rollback(() => res.status(500).send('Error crediting recipient'));

              db.commit(err => {
                if (err) return db.rollback(() => res.status(500).send('Commit failed'));
                res.redirect('/dashboard');
              });
            });
          });
        });
      });
    });
  });
});


app.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/');
});

app.get('/csrf-token', csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

app.listen(3000, () => {
  console.log('Secure web app running on http://localhost:3000');
});